The data cleaning scripts can be run in the following order:

1) add_wb.R: takes the raw data from the world bank (in the Data_Extract_full and Popular Indicators folders), makes them long format, and combines them
2) clean_temp.R: takes global temperature data (from country_temp.csv and data_global_temp.csv) and combines them
3) combine_all.R: combines the results from add_wb.R and clean_temp.R into one big data csv (called data_all.csv)