The data cleaning scripts can be run in the following order:

1) add_wb.R: takes the raw data from the world bank (in the Data_Extract_full and Popular Indicators folders), makes them long format, and combines them
2) clean_temp.R: takes global temperature data (from country_temp.csv and data_global_temp.csv) and combines them
3) combine_all.R: combines the results from add_wb.R and clean_temp.R into one big data csv (called data_all.csv)

Final output (in folder called 'final'):
data_all.csv: The .csv output from combine_all.R (includes data since 1991)
varnames_clean.csv: The .csv output from add_wb.R. This is a data dictionary for the world bank data
Note the meanings of the temperature time series codes:
1) WLD.TEMP.ANOMALY: world level data - difference between world surface temp and long term average
source: https://www.climate.gov/news-features/understanding-climate/climate-change-global-temperature#:~:text=Change%20over%20time&text=According%20to%20the%20NOAA%202019,more%20than%20twice%20as%20great
2) TEMP.YEARLY: country level data - time series of surface temp for each country
source: https://climateknowledgeportal.worldbank.org/download-data
3) WLD.AVG.TEMP.YEARLY: world level data - time series of the average world surface temperature (this is the average of TEMP.YEARLY over country)