#------------------------------------------------------------------------------#
# File: data_visualization.R
# Description: this file produces the main figures in the final report
# Outputs: the following .tiff files
#           - 
#------------------------------------------------------------------------------#

library(tidyverse) # for ggplot()

# Color blind friendly color scheme
cbp1 <- c("#999999", "#E69F00", "#56B4E9", "#009E73",
          "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# Read in the data
# Load in country level data
wide <- read.csv(paste0(getwd(), "/cleaning/final/data_wide_subset_t.csv"), 
                 stringsAsFactors = FALSE)
wide2 <- wide[wide$Country.Name != "world", ]

### Section 1: Violin plot of temperature differences for each country
p1 <- ggplot(data = wide, mapping = aes(x = Country.Name, y = temp.diff)) +
  geom_violin(mapping = aes(fill = Country.Name)) +
  scale_fill_manual(values = cbp1) + 
  geom_boxplot(width = 0.1) + 
  labs(fill = "Country", x = "Country", y = "Temperature Difference") + 
  ggtitle("Temperature difference distribution over countries") +
  theme_classic()
p1_2 <- p1 + theme(axis.text.x = element_text(angle = -45, hjust = 0))

ggsave(filename = paste0(getwd(), "/plots/Main Figures/tempdiff_vln.tiff"), 
       plot = p1_2, 
       width = 6, 
       height = 4, 
       units = "in")

### Section 2: Relationship between surface temperature and temp difference
p2 <- ggplot(data = wide, mapping = aes(x = year, y = TEMP.YEARLY)) +
  geom_line() +
  geom_point(mapping = aes(color = temp.diff)) + 
  scale_color_gradient(low = "blue", high = "red") +
  labs(color = "Temperature \n difference", 
       y = "Surface Temperature (Celsius)") + 
  facet_wrap(~ Country.Name, scales = "free_y") +
  ggtitle("Relationship between surface temperature and 
          temperature difference") +
  theme_classic()
p2

ggsave(filename = paste0(getwd(), "/plots/Main Figures/tempdiff_scatter.tiff"), 
       plot = p2, 
       width = 8, 
       height = 6, 
       units = "in")

### Section 3: Emissions over time for countries
p3 <- ggplot(wide2, aes(x = year, y = EN.ATM.CO2E.KT, fill = Country.Name)) + 
  geom_area() + 
  labs(fill = "Country", y = "CO2 emissions (kt)") +
  scale_fill_manual(values = cbp1) + 
  ggtitle("CO2 emissions by country") +
  theme_classic()
p3

ggsave(filename = paste0(getwd(), "/plots/Main Figures/CO2_time_fill.tiff"), 
       plot = p3, 
       width = 6, 
       height = 4, 
       units = "in")

### Section 4: Relationship between significant predictors in the regression
#              models and temperature difference
vars <- c("EN.ATM.CO2E.KT_log", "EG.USE.PCAP.KG.OE_log")
names <- c("CO2", "PCAP")

for(i in 1:length(vars)) {
  p4 <- ggplot(data = wide2, mapping = aes_string(x = "year", y = vars[i])) +
    geom_line() +
    geom_point(mapping = aes(color = temp.diff)) + 
    scale_color_gradient(low = "blue", high = "red") +
    labs(color = "Temperature \n difference", y = names[i]) + 
    facet_wrap(~ Country.Name, scales = "free_y") +
    ggtitle(paste0("Relationship between ", 
                   names[i], 
                   " and temperature difference")) +
    theme_classic()
  print(p4)
  
  ggsave(filename = paste0(getwd(), 
                           "/plots/Main Figures/", 
                           names[i], 
                           "tempdiff_scatter.tiff"), 
         plot = p4, 
         width = 8, 
         height = 5, 
         units = "in")
}