#------------------------------------------------------------------------------#
# File: data_visualization.R
# Description: this file produces the main figures in the final report
# Outputs: the following .tiff files
#           - 
#------------------------------------------------------------------------------#

library(tidyverse) # for ggplot()
# Color blind friendly color scheme
cbp1 <- c("#999999", "#E69F00", "#56B4E9", "#009E73",
          "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# Read in the data
# Load in country level data
wide <- read.csv(paste0(getwd(), "/cleaning/final/data_wide_subset_t.csv"), 
                 stringsAsFactors = FALSE)
wide2 <- wide[wide$Country.Name != "World", ]

# Variables of interest

### Section 1: Violin plot of temperature differences for each country

p1 <- ggplot(data = wide, mapping = aes(x = Country.Name, y = temp.diff)) +
  geom_violin(mapping = aes(fill = Country.Name)) +
  scale_fill_manual(values = cbp1) + 
  geom_boxplot(width = 0.1) + 
  labs(fill = "Country", x = "Country", y = series.defs[i]) + 
  ggtitle(paste0(series.defs[i] , " distribution over countries")) +
  theme_classic()
p1_2 <- p1 + theme(axis.text.x = element_text(angle = -45, hjust = 0))

picnm <- paste0(getwd(), "/plots/Main Figures/tempdiff_vln.tiff")
ggsave(filename = picnm, 
       plot = p1_2, 
       width = 6, 
       height = 4, 
       units = "in")

### Section 2: Relationship between surface temperature and temp difference
p2 <- ggplot(data = wide, mapping = aes(x = year, y = TEMP.YEARLY)) +
  geom_line() +
  geom_point(mapping = aes(color = temp.diff)) + 
  scale_color_gradient(low = "blue", high = "red") +
  labs(color = "Temperature \n difference", 
       y = "Surface Temperature (Celsius)") + 
  facet_wrap(~ Country.Name, scales = "free_y") +
  ggtitle("Relationship between surface temperature and 
          temperature difference") +
  theme_classic()
p2

ggsave(filename = paste0(getwd(), "/plots/Main Figures/tempdiff_scatter.tiff"), 
       plot = p2, 
       width = 8, 
       height = 6, 
       units = "in")

### Section 3: Relationship between significant predictors in the regression
#              models and temperature difference

series.names <- c("AG.SRF.TOTL.K2", 
                  "AG.LND.AGRI.ZS",
                  "EN.ATM.CO2E.KT_log",
                  "EG.USE.COMM.CL.ZS_sq",
                  "EG.FEC.RNEW.ZS_sq")
series.defs <- c("Surface area (sq. km)", 
                 "Agricultural land (% of land area)",
                 "log(CO2 Emissions) (kt)",
                 "Alternative/nuclear energy share(%)",
                 "Renewable Energy share")

for(i in 1:length(series.names)) {
  p4 <- ggplot(data = wide2, mapping = aes_string(x = "year", y = series.names[i])) +
    geom_line() +
    geom_point(mapping = aes(color = temp.diff)) + 
    scale_color_gradient(low = "blue", high = "red") +
    labs(color = "Temperature \n difference", y = series.defs[i]) + 
    facet_wrap(~ Country.Name, scales = "free_y", nrow = 1) +
    ggtitle(paste0("Relationship between ", 
                   series.defs[i], 
                   " and temperature difference")) +
    theme_classic()
  p4 <- p4 + theme(axis.text.x = element_text(angle = -45, hjust = 0))
  print(p4)
  
  picnm <- paste0(getwd(), "/plots/Main Figures/", 
                  series.names[i], "tempdiff_scatter.tiff")
  ggsave(filename = picnm, 
         plot = p4, 
         width = 10, 
         height = 3, 
         units = "in")
}