#------------------------------------------------------------------------------#
# File: data_transform.R
# Description: this file examines the selected variables in more detail to 
#              determine which variables should be transformed, and which
#              variables are correlated and should be removed from the analysis
# Outputs: the following .csv files
#           - country_aggregated_t.csv: contains data from 
#                                       country_aggregated.csv and the
#                                       transformed variables
#         the following .pdf files
#           - Supp_f1.pdf: contains the data transformation plots from Section 1
#           - Supp_f2.pdf: contains the pairs plots from Section 2
#------------------------------------------------------------------------------#

# Clear workspace
rm(list = ls())

library(e1071) # For calculating the skewness of the data using skewness()

# Read in the data
x_full <- read.csv(paste0(getwd(), "/cleaning/final/data_wide_subset.csv"), 
              stringsAsFactors = FALSE)
x_full$X <- NULL

# Exclude the world level variables before examining transformations
# This is because the world data are aggregated from the country data (so they
# are some linear combination of the country data like totals/averages that
# would throw off the histograms and scatterplots)
x <- x_full[x_full$Country.Name != "World", ]

### Section 1: Data transformation
# Plot histograms of each variable and of their transformations
# Also plot skewness of variable under each transformation
# Transforms used:
#   - No transform: x
#   - log: ln(x)
#   - square root: sqrt(x)
#   - squared: x^2
#   - z-standardized: (x-mean(x)) / sd(x)
#   - max-min: (x - min(x)) / (max(x) - min(x))
pdf(paste0(getwd(), "/plots/Supplementary Figures/Supp_f1.pdf"), 
    width = 9, height = 6)

plot.new()
text(0.5, 0.5, "Supplementary figure 1: Variable transformations \n 
In order to determine which variables to transform, each page corresponds to a 
variable. Each page contains plots of the variable and 5 transforms: log, 
square root, squared, z-score standardization, and
max-min ( (x - min) / (max - min) ). Each plot contains the histogram, the 
     kernel density estimate overlaid, and the skewness of the data.")

varnames <- names(x)[!(names(x) %in% c("year", "Country.Name"))]

for(j in 1:length(varnames)) {
  par(mfrow = c(2, 3))
  nm <- varnames[j]
  
  # No transform
  temp <- x[, nm]
  hist(temp,
       main = paste0(nm, "\n skew=", as.character(skewness(temp))),
       freq = FALSE)
  lines(density(temp))

  # log transform (note: the x[, j] > 0 requirement is to prevent errors for
  # some of the variables with negative values, but we will not be considering
  # the log transform for these types of variables)
  temp <- log(x[, nm][x[, nm] > 0])
  hist(temp,
       main = paste0("ln(", nm, ") \n skew=", as.character(skewness(temp))),
       freq = FALSE)
  lines(density(temp))

  # square root transform (note: the x[, j] > 0 requirement is to prevent errors 
  # for some of the variables with negative values, but we will not be 
  # considering the square root transform for these types of variables)
  temp <- sqrt(x[, nm][x[, nm] > 0])
  hist(temp,
       main = paste0("sqrt(", nm, ") \n skew=", as.character(skewness(temp))),
       freq = FALSE)
  lines(density(temp))

  # squared transform
  temp <- x[, nm]^2
  hist(temp,
       main = paste0(nm, "^2 \n skew=", as.character(skewness(temp))),
       freq = FALSE)
  lines(density(temp))

  # z-score transform
  temp <- scale(x[, nm])
  hist(temp,
       main = paste0("z-scale", nm, "\n skew=", as.character(skewness(temp))),
       freq = FALSE)
  lines(density(temp))

  # max-min transform
  temp <- (x[, nm] - min(x[, nm]))/(max(x[, nm] - min(x[, nm])))
  hist(temp,
       main = paste0("max-min", nm, "\n skew=", as.character(skewness(temp))),
       freq = FALSE)
  lines(density(temp))
}
dev.off()

# Based on the plots, try transforming the following variables
x$SP.DYN.LE00.FE.IN_sq <- x$SP.DYN.LE00.FE.IN^2
x$SP.DYN.LE00.MA.IN_sq <- x$SP.DYN.LE00.MA.IN^2
x$SL.UEM.TOTL.ZS_sqrt <- sqrt(x$SL.UEM.TOTL.ZS)
x$EN.POP.DNST_sqrt <- sqrt(x$EN.POP.DNST)
x$SP.URB.TOTL.IN.ZS_sq <- x$SP.URB.TOTL.IN.ZS^2
x$AG.PRD.LVSK.XD_sq <- x$AG.PRD.LVSK.XD^2
x$EN.ATM.CO2E.KT_log <- log(x$EN.ATM.CO2E.KT)
x$EG.USE.COMM.CL.ZS_sq <- x$EG.USE.COMM.CL.ZS^2
x$EG.USE.PCAP.KG.OE_log <- log(x$EG.USE.PCAP.KG.OE)
x$EG.FEC.RNEW.ZS_sq <- sqrt(x$EG.FEC.RNEW.ZS)

### Section 2: Multicollinearity
# There are too many variables to do a proper pairs plot
# Instead, iterate and put each plot in a separate page in a pdf
transformed <- c("SP.DYN.LE00.FE.IN",
                 "SP.DYN.LE00.MA.IN",
                 "SL.UEM.TOTL.ZS",
                 "EN.POP.DNST",
                 "SP.URB.TOTL.IN.ZS",
                 "AG.PRD.LVSK.XD",
                 "EN.ATM.CO2E.KT",
                 "EG.USE.COMM.CL.ZS",
                 "EG.USE.PCAP.KG.OE",
                 "EG.FEC.RNEW.ZS")
# Subset the data to only contain the transformed variables
xx <- x[, !(names(x) %in% transformed)]
xx$Country.Name <- as.factor(xx$Country.Name)
xx$X <- NULL

varpairs <- combn(names(xx), 2)
pdf(paste0(getwd(), "/plots/Supplementary Figures/Supp_f2.pdf"), 
    width = 5, height = 5)

plot.new()
text(0.5, 0.5, "Supplementary figure 2: Collinearity (pairs) plots
In order to determine which variables are correlated, 
each page corresponds to a scatterplot of a pairs plot 
(note: if y vs. x is plotted, then x vs. y is not plotted", cex = 3/4)

for(i in 1:ncol(varpairs)) {
  plot(xx[, varpairs[1, i]], xx[, varpairs[2, i]],
       xlab = varpairs[1, i], ylab = varpairs[2, i],
       main = paste0(varpairs[2, i], " vs. ", varpairs[1, i]))
}
dev.off()

# Save the country level aggregated data (do this on the full data that includes
# the world)
x_full$SP.DYN.LE00.FE.IN_sq <- x_full$SP.DYN.LE00.FE.IN^2
x_full$SP.DYN.LE00.MA.IN_sq <- x_full$SP.DYN.LE00.MA.IN^2
x_full$SL.UEM.TOTL.ZS_sqrt <- sqrt(x_full$SL.UEM.TOTL.ZS)
x_full$EN.POP.DNST_sqrt <- sqrt(x_full$EN.POP.DNST)
x_full$SP.URB.TOTL.IN.ZS_sq <- x_full$SP.URB.TOTL.IN.ZS^2
x_full$AG.PRD.LVSK.XD_sq <- x_full$AG.PRD.LVSK.XD^2
x_full$EN.ATM.CO2E.KT_log <- log(x_full$EN.ATM.CO2E.KT)
x_full$EG.USE.COMM.CL.ZS_sq <- x_full$EG.USE.COMM.CL.ZS^2
x_full$EG.USE.PCAP.KG.OE_log <- log(x_full$EG.USE.PCAP.KG.OE)
x_full$EG.FEC.RNEW.ZS_sq <- sqrt(x_full$EG.FEC.RNEW.ZS)
write.csv(x_full, paste0(getwd(), "/cleaning/final/", "data_wide_subset_t.csv"))