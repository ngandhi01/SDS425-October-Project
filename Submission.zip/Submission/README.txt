Description of files in this folder:
- The cleaning folder contains the raw data, cleaning scripts, and cleaned data. See README in that folder for more information
- The plots folder contains all plot pictures including Main Figures (included in the report) and Supplementary Figures (not in the report but used to inform our modeling)
- data_transform.R contains some exploratory analysis for constructing our models. In particular, it produces supplementary figures for our analysis contained in plots/Supplementary Figures
- data_visualization.R produces all of the main figures which can be found in plots/Main Figures
- modeling-script.R produces the models referenced in the report and their output
