#------------------------------------------------------------------------------#
# File: modeling=script.R
# Description: this file produces the main models in the final report
# Outputs: no file outputs 
#------------------------------------------------------------------------------#
library(MASS)

# Modeling 
xx <- read.csv(paste0(getwd(), "/cleaning/final/data_wide_subset_t.csv"), 
               stringsAsFactors = FALSE)

# Store the transformed information from cleaning script
transformed_world_dat <- xx

# Modeling the aggregated country level data to determine significant predictors
temp.yearly.model <- lm(TEMP.YEARLY ~ . - temp.diff, 
                        data = transformed_world_dat)
temp.yearly.model.step <- stepAIC(temp.yearly.model, direction = "both")
summary(temp.yearly.model.step)

# Predict the temperatures based off the significant predictors

# Create Training and Test data
# Setting seed to reproduce results of random sampling
set.seed(100)  
trainingRowIndex <- sample(1:nrow(transformed_world_dat), 
                           0.8*nrow(transformed_world_dat)) 
trainingData <- transformed_world_dat[trainingRowIndex, ]  
testData <- transformed_world_dat[-trainingRowIndex, ]   

# Predictions for average temperature based on significant predictors 
# found above 
lmMod.aggregated <- lm(TEMP.YEARLY ~ year + SP.POP.GROW + AG.SRF.TOTL.K2 
                       + AG.LND.AGRI.ZS + Country.Name + EN.ATM.CO2E.KT_log 
                       + EG.USE.COMM.CL.ZS_sq + EG.FEC.RNEW.ZS_sq, 
                       data = trainingData)
predictions <- predict(lmMod.aggregated, testData)
actuals_preds <- data.frame(cbind(actuals = testData$TEMP.YEARLY, 
                                  predicteds=predictions))

# Calculate accuracy
min_max_accuracy <- mean(apply(actuals_preds, 1, min) / apply(actuals_preds, 1, 
                                                              max))
print(paste("The Min/Max Accuracy of the Predictions for 
            Average Yearly Temperature is:", round(min_max_accuracy,3)))

# Repeat the above for temperature differences
temp.diff.model <- lm(temp.diff ~ . - TEMP.YEARLY, data = transformed_world_dat)
# Run stepwise regression in order to find the best predictors
temp.diff.model.step <- stepAIC(temp.diff.model, direction = "both")
summary(temp.diff.model.step)
# Significant predictors for yearly temperature are country, year, surface area 
# (sq km), atmospheric CO2, and renewable energy consumption 

# Predictions for average temperature based on significant predictors found 
# above 
lmMod.aggregated.anom <- lm(temp.diff ~ year + AG.SRF.TOTL.K2 + AG.LND.AGRI.ZS 
                            + Country.Name + EN.ATM.CO2E.KT_log 
                            + EG.USE.COMM.CL.ZS_sq + EG.FEC.RNEW.ZS_sq 
                            - TEMP.YEARLY, 
                            data = trainingData)
predictions <- predict(lmMod.aggregated.anom, testData)

actuals_preds <- data.frame(cbind(actuals = testData$temp.diff, 
                                  predicteds=predictions))

# Calculate accuracy
min_max_accuracy <- mean(apply(actuals_preds, 1, min) / apply(actuals_preds, 1, 
                                                              max))

print(paste("The Min/Max Accuracy of the Predictions for 
            Average Yearly Temperature Difference is:", 
            round(min_max_accuracy,3)))

# Moving on to the next portion of modeling 

# Now we will compare the above model with our aggregated information to world
# bank data aggregated world information


wb_data_long <- read.csv(paste0(getwd(), "/cleaning/final/data_long.csv"), 
                         stringsAsFactors = FALSE)

# Remove duplicate rows 
wb_data_long <- wb_data_long[which(!duplicated(wb_data_long[, 1:4])), ]

# Remove all the NA rows
wb_data_long <- wb_data_long[!is.na(wb_data_long$value),]

# Subset to only include information up until 2017
wb_data_long <- wb_data_long[!wb_data_long$year > 2017,]

# Extract only the world information
world_data <- wb_data_long[wb_data_long$Country.Name == "World",]

# Remove the country name and country code as this is irrelevant information in 
# this subsetted data 
world_data <- world_data[,-c(1,3,4)]

# Make the information in wide format so it is easier to model 
world_data_wide <- reshape(world_data, 
                           idvar = "year", 
                           timevar = "Series.Code", 
                           direction = "wide")

# Transform the data like in the transformation script
world_data_wide$value.SP.DYN.LE00.FE.IN <- 
  world_data_wide$value.SP.DYN.LE00.FE.IN^2
world_data_wide$value.SP.DYN.LE00.MA.IN <- 
  world_data_wide$value.SP.DYN.LE00.MA.IN^2
world_data_wide$value.SL.UEM.TOTL.ZS <- 
  sqrt(world_data_wide$value.SL.UEM.TOTL.ZS)
world_data_wide$value.EN.POP.DNST <- 
  sqrt(world_data_wide$value.EN.POP.DNST)
world_data_wide$value.SP.URB.TOTL.IN.ZS <- 
  world_data_wide$value.SP.URB.TOTL.IN.ZS^2
world_data_wide$value.AG.PRD.LVSK.XD <- 
  world_data_wide$value.AG.PRD.LVSK.XD^2
world_data_wide$value.EN.ATM.CO2E.KT <- 
  log(world_data_wide$value.EN.ATM.CO2E.KT)
world_data_wide$value.EG.USE.COMM.CL.ZS <- 
  world_data_wide$value.EG.USE.COMM.CL.ZS^2
world_data_wide$value.EG.USE.PCAP.KG.OE <- 
  log(world_data_wide$value.EG.USE.PCAP.KG.OE)
world_data_wide$value.EG.FEC.RNEW.ZS <- 
  sqrt(world_data_wide$value.EG.FEC.RNEW.ZS)

vars <- c("year",
          "value.WLD.AVG.TEMP.YEARLY",
          "value.SP.DYN.LE00.FE.IN", 
          "value.SP.DYN.LE00.MA.IN",
          "value.SL.UEM.TOTL.ZS",
          "value.EN.POP.DNST",
          "value.SP.POP.GROW",
          "value.SP.URB.TOTL.IN.ZS",
          "value.AG.SRF.TOTL.K2",
          "value.AG.PRD.LVSK.XD",
          "value.AG.LND.AGRI.ZS",
          "value.EN.ATM.CO2E.KT",
          "value.EG.USE.COMM.CL.ZS",
          "value.EG.USE.PCAP.KG.OE",
          "value.EG.FEC.RNEW.ZS")

# Maintain only those columns
world_data_wide <- world_data_wide[,vars]

# Take complete cases for linear regression
world_data_wide <- world_data_wide[complete.cases(world_data_wide),]

# Fit the models and determine significant predictors using stepwise selection 
# methods 
wld.temp.model <- lm(value.WLD.AVG.TEMP.YEARLY ~., data = world_data_wide)

# Stepwise regression for variable selection
wld.temp.model.step <- stepAIC(wld.temp.model, direction = "both")
summary(wld.temp.model.step)
# Significant predictors for Avg World Temperature are population density, and
# atmospheric CO2 emissions (in kT)

# Predict the temperatures based off the significant predictors

# Create Training and Test data
# Setting seed to reproduce results of random sampling
set.seed(100)  
trainingRowIndex <- sample(1:nrow(world_data_wide), 0.8*nrow(world_data_wide)) 
trainingData <- world_data_wide[trainingRowIndex, ]  
testData <- world_data_wide[-trainingRowIndex, ]   

# Predictions for average temperature based on significant predictors 
# found above 
lmMod.wld.temp <- lm(value.WLD.AVG.TEMP.YEARLY ~ value.EN.POP.DNST 
                     + value.EN.ATM.CO2E.KT 
                     + value.EG.FEC.RNEW.ZS, data = trainingData)
predictions <- predict(lmMod.wld.temp, testData)

actuals_preds <- data.frame(cbind(actuals = testData$value.WLD.AVG.TEMP.YEARLY, 
                                  predicteds=predictions))

# Calculate accuracy
min_max_accuracy <- mean(apply(actuals_preds, 1, min) / apply(actuals_preds, 1, 
                                                              max))
print(paste("The Min/Max Accuracy of the Predictions for 
            Average Yearly Temperature is:", round(min_max_accuracy,3)))