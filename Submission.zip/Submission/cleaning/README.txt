The file clean.R executes all of the necessary code to clean and aggregate data from the World Bank databank and
World Bank Climate Change Knowledge portal. This script has already been run and the required datasets can be
found in Submission/cleaning/final

Here is the header of clean.R which contains a description of the output data:
#------------------------------------------------------------------------------#
# File: clean.R
# Description: Cleans and combines data from the World Bank Databank and the
#              World Bank and the World Bank Climate Change Knowledge Portal.
# Last modified: 10/28/2020
# Outputs: the following .csv files
#           - data_long.csv: contains combined Databank and Climate Change
#                            Knowledge Portal data in long format
#           - varnames_clean.csv: contains each time series code in
#                                 data_long.csv as well as their definitions
#           - country_aggregated.csv: contains selected countries and variables
#                                     of interest in wide format
# Note: to minimize the number of .csv files created and rounding errors from
#       saving files to .csv and reading them in again, all data cleaning is
#       performed in a single script.
#------------------------------------------------------------------------------#